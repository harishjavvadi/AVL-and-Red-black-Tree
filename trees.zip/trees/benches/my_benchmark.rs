use criterion::{BenchmarkId, criterion_group, criterion_main, Criterion};
use trees::binarysearch::BinarySearchTree;
use trees::common::Tree;
use trees::avl::AVLTree;
use trees::redblack::RedBlackTree;
use rand::{rngs::StdRng, SeedableRng};
use rand::seq::{SliceRandom, IteratorRandom};


const TREE_SIZE: [i32; 5] = [10_000, 40_000, 70_000, 100_000, 130_000];


fn benchmark_search_bst(tree_size: i32) {
    let mut bst = BinarySearchTree::new();
    for v in 0..tree_size {
        bst.insert(v);
    }
    for v in 0..tree_size / 10 {
        bst.search(v);
    }
}

fn benchmark_insert_bst(tree_size: i32) {
    let mut bst = BinarySearchTree::new();
    for v in 0..tree_size {
        bst.insert(v);
    }
}

fn benchmark_bst_insert_delete(tree_size: i32) {
    let seed = [0u8; 32];
    let mut rng: StdRng = SeedableRng::from_seed(seed);
    let mut data: Vec<i32> = (0..tree_size).collect();
    data.shuffle(&mut rng);
    let sample = data.iter().choose_multiple(&mut rng, (tree_size / 10) as usize);

    let mut bst = BinarySearchTree::new();
    for v in &data {
        bst.insert(*v);
    }
    for v in sample.iter() {
        bst.delete(**v);
    }
}

fn benchmark_search_avl(tree_size: i32) {
    let mut avl = AVLTree::new();
    for v in 0..tree_size {
        avl.insert(v);
    }
    for v in 0..tree_size / 10 {
        avl.search(v);
    }
}


fn benchmark_insert_avl(tree_size: i32) {
    let mut avl = AVLTree::new();
    for v in 0..tree_size {
        avl.insert(v);
    }
}


fn benchmark_avl_insert_delete(tree_size: i32) {
    let seed = [0u8; 32];
    let mut rng: StdRng = SeedableRng::from_seed(seed);
    let mut data: Vec<i32> = (0..tree_size).collect();
    data.shuffle(&mut rng);
    let sample = data.iter().choose_multiple(&mut rng, (tree_size / 10) as usize);

    let mut avl = AVLTree::new();
    for v in &data {
        avl.insert(*v);
    }
    for v in sample.iter() {
        avl.delete(**v);
    }
}

fn benchmark_search_rbt(tree_size: i32) {
    let mut rbt = RedBlackTree::new();
    for v in 0..tree_size {
        rbt.insert(v);
    }
    for v in 0..tree_size / 10 {
        rbt.search(v);
    }
}

fn benchmark_insert_rbt(tree_size: i32) {
    let mut rbt = RedBlackTree::new();
    for v in 0..tree_size {
        rbt.insert(v);
    }
}

fn benchmark_rbt_insert_delete(tree_size: i32) {
    let seed = [0u8; 32];
    let mut rng: StdRng = SeedableRng::from_seed(seed);
    let mut data: Vec<i32> = (0..tree_size).collect();
    data.shuffle(&mut rng);
    let sample = data.iter().choose_multiple(&mut rng, (tree_size / 10) as usize);

    let mut rbt = RedBlackTree::new();
    for v in &data {
        rbt.insert(*v);
    }

    for v in sample.iter() {
        rbt.delete(**v);
    }
}

fn bench_insert_compare(c: &mut Criterion) {
    let mut group = c.benchmark_group("Compare Insertion Operation");
    for (idx, size) in TREE_SIZE.iter().enumerate() {
        group.bench_with_input(
            BenchmarkId::new("BST", idx), size,
            |b, i| b.iter(|| benchmark_insert_bst(*i))
        );
        group.bench_with_input(
            BenchmarkId::new("AVL", idx), size,
            |b, i| b.iter(|| benchmark_insert_avl(*i))
        );
        group.bench_with_input(
            BenchmarkId::new("RBT", idx), size,
            |b, i| {
                b.iter(|| benchmark_insert_rbt(*i));
            }
        );
    }
    group.finish();
}



fn bench_search_compare(c: &mut Criterion) {
    let mut group = c.benchmark_group("Compare Search Operation");
    for (idx, size) in TREE_SIZE.iter().enumerate() {
        group.bench_with_input(
            BenchmarkId::new("BST", idx), size,
            |b, i| b.iter(|| benchmark_search_bst(*i))
        );
        group.bench_with_input(
            BenchmarkId::new("AVL", idx), size,
            |b, i| b.iter(|| benchmark_search_avl(*i))
        );
        group.bench_with_input(
            BenchmarkId::new("RBT", idx), size,
            |b, i| {
                b.iter(|| benchmark_search_rbt(*i));
            }
        );
    }
    group.finish();
}

fn bench_compare_insert_delete(c: &mut Criterion) {
    let mut group = c.benchmark_group("Compare Deletion Operation");
    for (idx, size) in TREE_SIZE.iter().enumerate() {
        group.bench_with_input(
            BenchmarkId::new("BST", idx), size,
            |b, i| b.iter(|| benchmark_bst_insert_delete(*i))
        );
        group.bench_with_input(
            BenchmarkId::new("AVL", idx), size,
            |b, i| b.iter(|| benchmark_avl_insert_delete(*i))
        );
        group.bench_with_input(
            BenchmarkId::new("RBT", idx), size,
            |b, i| {
                b.iter(|| benchmark_rbt_insert_delete(*i));
            }
        );
    }
    group.finish();
}

criterion_group!(
    benches,
    bench_search_compare,
    bench_insert_compare,
    bench_compare_insert_delete,
);
criterion_main!(benches);