
use std::cell::RefCell;
use std::fmt;
use std::rc::Rc;

use crate::common::{Tree, TreeNode};

type RcRefRBTNode<T> = Rc<RefCell<RedBlackTreeNode<T>>>;
type RBNodeLink<T> = Option<RcRefRBTNode<T>>;
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum NodeColour {
    Red,
    Black,
}

pub struct RedBlackTreeNode<T: Ord + Copy + fmt::Debug> {

    pub data: T,
    pub colour: NodeColour,
    parent: RBNodeLink<T>,
    left: RBNodeLink<T>,
    right: RBNodeLink<T>,
}

impl<T: Ord + Copy + fmt::Debug> RedBlackTreeNode<T> {

    fn new(data: T, colour: NodeColour, parent: RBNodeLink<T>) -> RcRefRBTNode<T> {
        Rc::new(RefCell::new(Self {
            data: data,
            colour,
            parent,
            left: None,
            right: None,
        }))
    }

pub fn print_tree_str(node: Option<Rc<RefCell<RedBlackTreeNode<T>>>>, prefix: String, is_left: bool) {
    match node {
        Some(node) => {
            let data_of_node = node.borrow().data;
            let colour = match node.borrow().colour {
                NodeColour::Red => "\x1b[31;47mRed\x1b[0m",    // Red text with white background
                NodeColour::Black => "\x1b[30;47mBlack\x1b[0m", // Black text with white background
            };

            let connector = if is_left { "└── " } else { "┌── " };

            println!("{}{} {:?} - {}", prefix, connector, data_of_node, colour);

            let child_prefix = format!("{}{}", prefix, if is_left { "    " } else { "│   " });

            let right = node.borrow().right.clone();
            Self::print_tree_str(right, child_prefix.clone(), false);

            let left = node.borrow().left.clone();
            Self::print_tree_str(left, child_prefix, true);
        }
        None => (),
    }
}

    
    fn right_rotation(node: RcRefRBTNode<T>) -> RBNodeLink<T> {
        let parent = node.borrow().parent.clone();
        let left = node.borrow().left.clone();
        node.borrow_mut().left = left.clone().unwrap().borrow().right.clone();
        if node.borrow().left.is_some() {
            let left = node.borrow().left.clone().unwrap();
            left.borrow_mut().parent = Some(node.clone());
        }
        node.borrow_mut().parent = left.clone();
        left.clone().unwrap().borrow_mut().right = Some(node.clone());
        if parent.is_some() {
            let right = parent.clone().unwrap().borrow().right.clone();
            match right {
                Some(right) if Rc::ptr_eq(&right, &node) => {
                    parent.clone().unwrap().borrow_mut().right = left.clone();
                }
                _ => parent.clone().unwrap().borrow_mut().left = left.clone(),
            }
        }

        left.clone().unwrap().borrow_mut().parent = parent;
        left
    }
    fn left_rotation(node: RcRefRBTNode<T>) -> RBNodeLink<T> {
        let parent = node.borrow().parent.clone();
        let right = node.borrow().right.clone();
        node.borrow_mut().right = right.clone().unwrap().borrow().left.clone();
        if node.borrow().right.is_some() {
            let right = node.borrow().right.clone().unwrap();
            right.borrow_mut().parent = Some(node.clone());
        }
        node.borrow_mut().parent = right.clone();
        right.clone().unwrap().borrow_mut().left = Some(node.clone());
        if parent.is_some() {
            let left = parent.clone().unwrap().borrow().left.clone();
            match left {
                Some(left) if Rc::ptr_eq(&left, &node) => {
                    parent.clone().unwrap().borrow_mut().left = right.clone();
                }
                _ => parent.clone().unwrap().borrow_mut().right = right.clone(),
            }
        }

        right.clone().unwrap().borrow_mut().parent = parent;
        right
    }
    fn insert(node: RcRefRBTNode<T>, data: T) -> RBNodeLink<T> {
        let data_of_node = node.borrow().data;
        if data_of_node == data {
            return Some(node);
        } else if data_of_node > data {
            let left = node.borrow().left.clone();
            match left {
                Some(left) => {
                    Self::insert(left, data);
                }
                None => {
                    node.borrow_mut().left =
                        Some(Self::new(data, NodeColour::Red, Some(node.clone())));
                    let left = node.borrow().left.clone();
                    Self::insert_repair(left.unwrap());
                }
            }
        } else {
            let right = node.borrow().right.clone();
            match right {
                Some(right) => {
                    Self::insert(right, data);
                }
                None => {
                    node.borrow_mut().right =
                        Some(Self::new(data, NodeColour::Red, Some(node.clone())));
                    let right = node.borrow().right.clone().unwrap();
                    Self::insert_repair(right);
                }
            }
        }

        let parent = node.borrow().parent.clone();
        if parent.is_some() {
            parent
        } else {
            Some(node)
        }
    }

    fn insert_repair(node: RcRefRBTNode<T>) {
        let parent = node.borrow().parent.clone();
        match parent {
            None => node.borrow_mut().colour = NodeColour::Black,
             Some(parent) if Self::colour(Some(parent.clone())) == NodeColour::Black => {
              node.borrow_mut().colour = NodeColour::Red;
            }
            Some(parent) => {
                let uncle = Self::sibling(parent.clone());
                match Self::colour(uncle.clone()) {
                    NodeColour::Black => {
                        if Self::is_left(node.clone()) && Self::is_right(parent.clone()) {
                            Self::right_rotation(parent);
                            let right = node.borrow().right.clone();
                            Self::insert_repair(right.unwrap())
                        } else if Self::is_right(node.clone()) && Self::is_left(parent.clone()) {
                            Self::left_rotation(parent);
                            let left = node.borrow().left.clone();
                            Self::insert_repair(left.unwrap());
                        } else if Self::is_left(node.clone()) {
                            let grandpa = Self::grandpa(node.clone());
                            Self::right_rotation(grandpa.unwrap());
                            let parent = node.borrow().parent.clone();
                            let parent = parent.unwrap();
                            parent.borrow_mut().colour = NodeColour::Black;
                            let right = parent.borrow().right.clone();
                            right.unwrap().borrow_mut().colour = NodeColour::Red;
                        } else {
                            let grandpa = Self::grandpa(node.clone());
                            Self::left_rotation(grandpa.unwrap());
                            let parent = node.borrow().parent.clone();
                            let parent = parent.unwrap();
                            parent.borrow_mut().colour = NodeColour::Black;
                            let left = parent.borrow().left.clone();
                            left.unwrap().borrow_mut().colour = NodeColour::Red;
                        }
                    }
                    NodeColour::Red => {
                        parent.borrow_mut().colour = NodeColour::Black;
                        uncle.unwrap().borrow_mut().colour = NodeColour::Black;
                        let grandpa = Self::grandpa(node.clone()).unwrap();
                        grandpa.borrow_mut().colour = NodeColour::Red;
                        Self::insert_repair(grandpa);
                    }
                }
            }
        }
    }

    fn delete(node: RcRefRBTNode<T>, val: T) -> RBNodeLink<T> {
        let data_of_node = node.borrow().data;
        if data_of_node == val {
            let left = node.borrow().left.clone();
            let right = node.borrow().right.clone();
            match (left.clone(), right.clone()) {
                (Some(left), Some(_right)) => {
                    let v = Self::get_maximum(left.clone());
                    node.borrow_mut().data = v;
                    Self::delete(left, v);
                }
                _ => {
                    if node.borrow().colour == NodeColour::Red {
                        let parent = node.borrow().parent.clone().unwrap();
                        if Self::is_left(node.clone()) {
                            parent.borrow_mut().left = None;
                        } else {
                            parent.borrow_mut().right = None;
                        }
                    } else {
                        if left.is_none() && right.is_none() {
                            let parent = node.borrow().parent.clone();
                            match parent {
                                None => return None,
                                Some(_parent) => {
                                    Self::deletion_repair(node.clone());
                                    let parent = node.borrow().parent.clone();
                                    let parent = parent.unwrap();
                                    if Self::is_left(node.clone()) {
                                        parent.borrow_mut().left = None;
                                    } else {
                                        parent.borrow_mut().right = None;
                                    }
                                    node.borrow_mut().parent = None;
                                }
                            }
                        }
                        else {
                            let child = left.unwrap_or_else(|| right.unwrap());
                            let child_data = child.borrow().data;
                            let left_child = child.borrow().left.clone();
                            let right_child = child.borrow().right.clone();
                            node.borrow_mut().data = child_data;
                            node.borrow_mut().left = left_child;
                            node.borrow_mut().right = right_child;
                            if node.borrow().left.is_some() {
                                let left = node.borrow().left.clone().unwrap();
                                left.borrow_mut().parent = Some(node.clone());
                            }
                            if node.borrow().right.is_some() {
                                let right = node.borrow().right.clone().unwrap();
                                right.borrow_mut().parent = Some(node.clone());
                            }
                        }
                    }
                }
            }
        } else if data_of_node > val {
            let left = node.borrow().left.clone();
            if left.is_some() {
                Self::delete(left.unwrap(), val);
            }
        } else {
            let right = node.borrow().right.clone();
            if right.is_some() {
                Self::delete(right.unwrap(), val);
            }
        }

        let parent = node.borrow().parent.clone();
        if parent.is_some() {
            parent
        } else {
            Some(node)
        }
    }

    fn deletion_repair(node: RcRefRBTNode<T>) {
        let sib_node = Self::sibling(node.clone());
        if Self::colour(sib_node.clone()) == NodeColour::Red {
            let sib_node = sib_node.unwrap();
            sib_node.borrow_mut().colour = NodeColour::Black;
            let parent = node.borrow().parent.clone().unwrap();
            parent.borrow_mut().colour = NodeColour::Red;
            if Self::is_left(node.clone()) {
                Self::left_rotation(parent);
            } else {
                Self::right_rotation(parent);
            }
        }

        let sib_node = Self::sibling(node.clone());
        let parent = node.borrow().parent.clone();
        if Self::colour(parent.clone()) == NodeColour::Black
            && Self::colour(sib_node.clone()) == NodeColour::Black
        {
            match sib_node {
                Some(sib_node) =>{
            let left = sib_node.borrow().left.clone();
            let right = sib_node.borrow().right.clone();
            if Self::colour(left) == NodeColour::Black && Self::colour(right) == NodeColour::Black {
                sib_node.borrow_mut().colour = NodeColour::Red;
                Self::deletion_repair(parent.unwrap());
                return;
            }
        }
         None =>{
          }
        }
     }
        let sib_node = Self::sibling(node.clone());
        let parent = node.borrow().parent.clone();
        if Self::colour(parent.clone()) == NodeColour::Red
            && Self::colour(sib_node.clone()) == NodeColour::Black
        {
            let sib_node = sib_node.unwrap();
            let left = sib_node.borrow().left.clone();
            let right = sib_node.borrow().right.clone();
            if Self::colour(left) == NodeColour::Black && Self::colour(right) == NodeColour::Black {
                sib_node.borrow_mut().colour = NodeColour::Red;
                parent.unwrap().borrow_mut().colour = NodeColour::Black;
                return;
            }
        }

        let sib_node = Self::sibling(node.clone());
        if Self::is_left(node.clone()) && Self::colour(sib_node.clone()) == NodeColour::Black {
            let sib_node = sib_node.unwrap();
            let left = sib_node.borrow().left.clone();
            let right = sib_node.borrow().right.clone();
            if Self::colour(right.clone()) == NodeColour::Black && Self::colour(left) == NodeColour::Red
            {
                Self::right_rotation(sib_node);
                let sib_node = Self::sibling(node.clone());
                let sib_node = sib_node.unwrap();
                sib_node.borrow_mut().colour = NodeColour::Black;
                let right = sib_node.borrow().right.clone();
                let right = right.unwrap();
                right.borrow_mut().colour = NodeColour::Red;
            }
        }

        let sib_node = Self::sibling(node.clone());
        if Self::is_right(node.clone()) && Self::colour(sib_node.clone()) == NodeColour::Black {
            let sib_node = sib_node.unwrap();
            let left = sib_node.borrow().left.clone();
            let right = sib_node.borrow().right.clone();
            if Self::colour(right.clone()) == NodeColour::Red
                && Self::colour(left.clone()) == NodeColour::Black
            {
                Self::left_rotation(sib_node);
                let sib_node = Self::sibling(node.clone());
                let sib_node = sib_node.unwrap();
                sib_node.borrow_mut().colour = NodeColour::Black;
                let left = sib_node.borrow().left.clone();
                let left = left.unwrap();
                left.borrow_mut().colour = NodeColour::Red;
            }
        }

        let sib_node = Self::sibling(node.clone());
        if Self::is_left(node.clone()) && Self::colour(sib_node.clone()) == NodeColour::Black {
            let sib_node = sib_node.unwrap();
            let right = sib_node.borrow().right.clone();
            if Self::colour(right.clone()) == NodeColour::Red {
                let parent = node.borrow().parent.clone();
                Self::left_rotation(parent.unwrap());
                let grandpa = Self::grandpa(node.clone()).unwrap();
                let parent = node.borrow().parent.clone();
                let parent = parent.unwrap();
                grandpa.borrow_mut().colour = parent.borrow().colour;
                parent.borrow_mut().colour = NodeColour::Black;
                let sibling = Self::sibling(parent).unwrap();
                sibling.borrow_mut().colour = NodeColour::Black;
            }
        }

        let sib_node = Self::sibling(node.clone());
        if Self::is_right(node.clone()) && Self::colour(sib_node.clone()) == NodeColour::Black {
            let sib_node = sib_node.unwrap();
            let left = sib_node.borrow().left.clone();
            if Self::colour(left.clone()) == NodeColour::Red {
                Self::right_rotation(parent.clone().unwrap());
                let grandpa = Self::grandpa(node.clone()).unwrap();
                let parent = node.borrow().parent.clone();
                let parent = parent.unwrap();
                grandpa.borrow_mut().colour = parent.borrow().colour;
                parent.borrow_mut().colour = NodeColour::Black;
                let sibling = Self::sibling(parent).unwrap();
                sibling.borrow_mut().colour = NodeColour::Black;
            }
        }
    }



    #[allow(dead_code)]
    fn check_colour_properties(node: RcRefRBTNode<T>) -> bool {
        if node.borrow().colour == NodeColour::Red {
            return false;
        }
        if !Self::check_colouring(node.clone()) {
            return false;
        }
        if Self::height_of_balck(Some(node)).is_none() {
            return false;
        }
        true
    }
         fn check_colouring(node: RcRefRBTNode<T>) -> bool {
            if node.borrow().colour == NodeColour::Red {
                if Self::colour(node.borrow().left.clone()) == NodeColour::Red
                    || Self::colour(node.borrow().right.clone()) == NodeColour::Red
                {
                    return false;
                }
            }
    
            let left = node.borrow().left.clone();
            match left {
                Some(left) => {
                    if !Self::check_colouring(left) {
                        return false;
                    }
                }
                None => (),
            }
    
            let right = node.borrow().right.clone();
            match right {
                Some(right) => {
                    if !Self::check_colouring(right) {
                        return false;
                    }
                }
                None => (),
            }
    
            true
        }

    fn height_of_balck(node: RBNodeLink<T>) -> Option<usize> {
        match node {
            None => Some(1),
            Some(node) => {
                let lh = Self::height_of_balck(node.borrow().left.clone());
                let rh = Self::height_of_balck(node.borrow().right.clone());
                match (lh, rh) {
                    (Some(lh), Some(rh)) => {
                        if lh != rh {
                            None
                        } else {
                            let node_colour = node.borrow().colour;
                            match node_colour {
                                NodeColour::Red => Some(lh),
                                NodeColour::Black => Some(lh + 1),
                            }
                        }
                    }
                    _ => None,
                }
            }
        }
    }
    #[allow(dead_code)]
    fn search(node: RcRefRBTNode<T>, v: T) -> RBNodeLink<T> {
        let data_of_node = node.borrow().data;
        if data_of_node == v {
            Some(node)
        } else if v > data_of_node {
            let right = node.borrow().right.clone();
            match right {
                None => None,
                Some(right) => Self::search(right, v),
            }
        } else {
            let left = node.borrow().left.clone();
            match left {
                None => None,
                Some(left) => Self::search(left, v),
            }
        }
    }

    fn get_maximum(node: RcRefRBTNode<T>) -> T {
       match node.borrow().right.clone() {
           Some(right) => Self::get_maximum(right),
           None => node.borrow().data,
       }
   }

    fn grandpa(node: RcRefRBTNode<T>) -> RBNodeLink<T> {
        match node.borrow().parent.clone() {
            Some(parent) => parent.borrow().parent.clone(),
            _ => None,
        }
    }

    fn sibling(node: RcRefRBTNode<T>) -> RBNodeLink<T> {
        match node.borrow().parent.clone() {
            None => None,
            Some(parent) => {
                let left = parent.borrow().left.clone();
                match left {
                    Some(left) if Rc::ptr_eq(&left, &node) => parent.borrow().right.clone(),
                    _ => left,
                }
            }
        }
    }

    fn is_left(node: RcRefRBTNode<T>) -> bool {
        match node.borrow().parent.clone() {
            Some(parent) => match parent.borrow().left.clone() {
                Some(left) => Rc::ptr_eq(&left, &node),
                None => false,
            },
            _ => false,
        }
    }

    fn is_right(node: RcRefRBTNode<T>) -> bool {
        match node.borrow().parent.clone() {
            Some(parent) => match parent.borrow().right.clone() {
                Some(right) => Rc::ptr_eq(&right, &node),
                None => false,
            },
            _ => false,
        }
    }

    fn colour(node: RBNodeLink<T>) -> NodeColour {
        match node {
            None => NodeColour::Black,
            Some(v) => v.borrow().colour,
        }
    }
    #[allow(dead_code)]
    fn is_equal(left: RBNodeLink<T>, right: RBNodeLink<T>) -> bool {
        match (left, right) {
            (None, None) => true,
            (Some(_), None) | (None, Some(_)) => false,
            (Some(left), Some(right)) => {
                let left_data = left.borrow().data;
                let right_data = right.borrow().data;
                //Test if 2 trees are equal
                if left_data == right_data {
                    let left_left = left.borrow().left.clone();
                    let left_right = left.borrow().right.clone();
                    let right_left = right.borrow().left.clone();
                    let right_right = right.borrow().right.clone();
                    Self::is_equal(left_left, right_left) && Self::is_equal(left_right, right_right)
                } else {
                    false
                }
            }
        }
    }

    #[allow(dead_code)]
    fn preorder_traversal(node: RcRefRBTNode<T>, holder: &mut Vec<T>) {
        holder.push(node.borrow().data);
        let left = node.borrow().left.clone();
        if left.is_some() {
            Self::preorder_traversal(left.unwrap(), holder);
        }
        let right = node.borrow().right.clone();
        if right.is_some() {
            Self::preorder_traversal(right.unwrap(), holder);
        }
    }
    #[allow(dead_code)]
    fn inorder_traversal(node: RcRefRBTNode<T>, holder: &mut Vec<T>) {
        let left = node.borrow().left.clone();
        if left.is_some() {
            Self::inorder_traversal(left.unwrap(), holder);
        }
        holder.push(node.borrow().data);
        let right = node.borrow().right.clone();
        if right.is_some() {
            Self::inorder_traversal(right.unwrap(), holder);
        }
    }
    #[allow(dead_code)]
    fn postorder_traversal(node: RcRefRBTNode<T>, holder: &mut Vec<T>) {
        let left = node.borrow().left.clone();
        if left.is_some() {
            Self::postorder_traversal(left.unwrap(), holder);
        }
        let right = node.borrow().right.clone();
        if right.is_some() {
            Self::postorder_traversal(right.unwrap(), holder);
        }
        holder.push(node.borrow().data);
    }

    fn clear_tree(&mut self) {
        self.parent = None;
        match self.left.take() {
            None => {},
            Some(node) => {
                node.borrow_mut().clear_tree();
            }
        }
        self.left = None;
        match self.right.take() {
            None => {},
            Some(node) => {
                node.borrow_mut().clear_tree();
            }
        }
        self.right = None;
    }
}
pub struct RedBlackTree<T: Ord + Copy + fmt::Debug> {
    root: RBNodeLink<T>,
}

impl<T: Ord + Copy + fmt::Debug> Drop for RedBlackTree<T> {
    fn drop(&mut self) {
        match self.root.take() {
            Some(node) => node.borrow_mut().clear_tree(),
            None => return
        }
    }
}

impl<T: Ord + Copy + fmt::Debug> Drop for RedBlackTreeNode<T> {
    fn drop(&mut self) {
        self.clear_tree();
    }
}

impl<T: Ord + Copy + fmt::Debug> TreeNode<T> for RedBlackTreeNode<T> {
    fn get_left(&self) -> &RBNodeLink<T> {
        return &self.left;
    }
    fn get_right(&self) -> &RBNodeLink<T> {
        return &self.right;
    }
    fn get_data(&self) -> T {
        return self.data;
    }
}

impl<T: Ord + Copy + fmt::Debug> Tree<T, RedBlackTreeNode<T>> for RedBlackTree<T> {
    fn get_root(&self) -> &RBNodeLink<T> {
        &self.root
    }
}

impl<T: Ord + Copy + fmt::Debug> RedBlackTree<T> {
    pub fn new() -> Self {
        Self { root: None }
    }
    pub fn insert(&mut self, val: T) {
        match self.root.clone() {
            Some(root) => {
                let r = RedBlackTreeNode::insert(root, val);
                self.root = r;
            }
            None => {
                self.root = Some(Rc::new(RefCell::new(RedBlackTreeNode {
                    data: val,
                    colour: NodeColour::Black,
                    parent: None,
                    left: None,
                    right: None,
                })));
            }
        }
    }
    pub fn delete(&mut self, val: T) {
        match self.root.clone() {
            Some(root) => {
                let r = RedBlackTreeNode::delete(root, val);
                self.root = r;
            }
            None => (),
        }
    }
    #[allow(dead_code)]
    fn is_equal(&self, other: &RedBlackTree<T>) -> bool {
        RedBlackTreeNode::is_equal(self.root.clone(), other.root.clone())
    }

    pub fn print_tree_str(&self) {
        if let Some(root) = self.root.clone(){
            RedBlackTreeNode::<T>::print_tree_str(Some(root), String::new(), false);
        }
    }
}