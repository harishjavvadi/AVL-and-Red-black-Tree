use trees::redblack::RedBlackTree;
use trees::avl::AVLTree;
use trees::binarysearch::BinarySearchTree;
use trees::common::Tree;
use std::io::{stdin, stdout, Write};

pub fn run_comm_line_int(){
        loop {
            println!("To choose Red Black Tree: Enter -> rbt \nTo choose AVL Tree: Enter -> avl \nTo choose Binary Search Tree choose: Enter -> bst \n To Exit from the CLI: Enter -> exit \n");
            print!("Enter your choice:  ");
            let selected_tree = user_input();
    
            match selected_tree.to_lowercase().trim() {
                "rbt" => {
                    rbt_comm_line_int();
                },
                "avl" => {
                    avl_comm_line_int();
                },
                "bst" => {
                    bst_comm_line_int();
                },
                "help" => {
                    println!("The Commands that are available are:\n    \n");
                    println!("exit - To Exit from the CLI");
                    println!("rbt  - To work on RBT.");
                    println!("avl  - To work on AVL.");
                    println!("bst  - To work on BST.");
                },
                "exit" => break,
                _ => {
                    eprint!("The entered command is not found. \n");
                }
            }
        }
    }
    
    pub fn ops_list(){
        println!("\nThe below are the availabe operations that can be performed: \n               \n");
        println!("(a) insert            -    To insert a new node into the tree.");
        println!("(b) delete            -    To delete a node from the tree.");
        println!("(c) count             -    To count the number of leaves of the tree.");
        println!("(d) height            -    To find the height of the tree");
        println!("(e) print inorder     -    To print the values of tree in order");
        println!("(f) empty             -    To check whether the tree is empty or not");
        println!("(g) print tree        -    To print the complete tree structure");
        println!("(h) length            -    To find the length of the tree");
        println!("(i) maximum           -    To find the maximum value in the tree");
        println!("(j) minimum           -    To find the minimum value in the tree");
        println!("(k) search            -    To check if the tree contains a certain number or not");
        println!("(l) exit              -    To exit the current tree\n");
        println!("Please enter your choice");
    }
    
    pub fn user_input() -> String {
        let mut line = String::new();
        stdout().flush().expect("failed to flush");
        stdin().read_line(&mut line).expect("failed to read from stdin");
        line.to_string()
    }
    
    pub fn user_value(op: &str)-> i32 {
        loop {
            print!("{} value > ", op);
            let value = user_input();
            let trimmed_val = value.trim();
            match trimmed_val.parse::<i32>(){
                Ok(val) => {
                    println!("'{}' operation is performed on the value '{}' in the tree.",op,val);
                    return val;
                },
                Err(..) => {
                    println!("the given value is not an integer. please try again");
                },
            };
        }
    }
    
    fn rbt_comm_line_int() {
        println!("\n     Red-Black Tree branch     \n");
        let mut tree = RedBlackTree::<i32>::new();
        ops_list();
    
        loop {
            print!("operation > ");
            let operation = user_input();
    
            match operation.to_lowercase().trim() {
                "insert"  => {
                    let val = user_value("insert");
                    tree.insert(val);
                },
                "delete" => {
                    let val = user_value("delete");
                    tree.delete(val);
                },
    
                "contain" | "search" => {
                    let val = user_value("search");
                    println!("values found? {:?}", tree.search(val));
                },
                "height" => println!("Height of tree: {:?}", tree.height()),
                "count" => println!("Number of leaves: {:?}", tree.leaves()),
                "length" => println!("Length: {:?}", tree.length()),
                "minimum" => {
                    let min_val = tree.minimum_value();
                    match min_val {
                        None => println!("It is an empty tree!"),
                        Some(v) => println!("Minimum Value: {:?}", v),
                    }
                },
                "maximum" => {
                    let max_val = tree.maximum();
                    match max_val {
                        None => println!("It is an empty tree!"),
                        Some(v) => println!("Maximum Value: {:?}", v),
                    }
                },
                "empty" => println!("Is the tree empty?: {:?}", tree.empty_tree()),
                "print tree" => {print!("Your tree: \n");
                   tree.print_tree_str();},
                "print inorder" => {print!("Your tree: ");
                   tree.print_inorder();},
    
                "exit" => return,
                _ => println!("Command not recognized. Try 'help' for valid operations"),
            }
        }
    }
    
    fn avl_comm_line_int() {
        println!("\n     AVL Tree     \n");
        let mut tree = AVLTree::<i32>::new();
        ops_list();
    
        loop {
            print!("operation > ");
            let operation = user_input();
            match operation.to_lowercase().trim() {
                "insert"  => {
                    let val = user_value("insert");
                    tree.insert(val);
                },
                "delete" => {
                    let val = user_value("delete");
                    tree.delete(val);
                },
                "length" => println!("Length: {:?}", tree.length()),
                "height" => println!("Height of tree: {:?}", tree.height()),
                "empty" => println!("Is the tree empty?: {:?}", tree.empty_tree()),
                "count"  => println!("Number of leaves: {:?}", tree.leaves()),
                "search" => {
                    let val = user_value("search");
                    println!("values found? {:?}", tree.search(val));
                },
                "maximum"    => {
                    let max_val = tree.maximum();
                    match max_val {
                        None => println!("The tree is empty"),
                        Some(v) => println!("Maximum Value: {:?}", v),
                    }
                },
                 "minimum" => {
                    let min_val = tree.minimum_value();
                    match min_val {
                        None => println!("The tree is empty"),
                        Some(v) => println!("Minimum Value: {:?}", v),
                    }
                },
                "print tree" => {print!("Your tree: \n"); 
                tree.print_tree_str();},
                "print inorder"=> {print!("Your tree:");
                    tree.print_inorder();},
                "exit" => return,
                _ => println!("Command not recognized. Try 'help' for valid operations"),
            }
        }
    }
    
    fn bst_comm_line_int() {
        println!("\n     Binary-Search Tree      \n");
        let mut tree = BinarySearchTree::<i32>::new();
        ops_list();
    
        loop {
            print!("operation > ");
            let operation = user_input();
    
            match operation.to_lowercase().trim() {
                "insert"  => {
                    let val = user_value("insert");
                    tree.insert(val);
                },
                "delete" => {
                    let val = user_value("delete");
                    tree.delete(val);
                },
    
                "search" => {
                    let val = user_value("search");
                    println!("Presence of the value in the tree: {:?}", tree.search(val));
                },
                "height" => println!("Height of the tree: {:?}", tree.height()),
                "count" => println!("Number of leaves in the tree: {:?}", tree.leaves()),
                "length" => println!("Length of the tree: {:?}", tree.length()),
                "minimum" => {
                    let min_val = tree.minimum_value();
                    match min_val {
                        None => println!("The tree is empty"),
                        Some(v) => println!("Minimum Value in the tree is: {:?}", v),
                    }
                },
                "maximum" => {
                    let max_val = tree.maximum();
                    match max_val {
                        None => println!("The tree is empty!"),
                        Some(v) => println!("Maximum Value in the tree is: {:?}", v),
                    }
                },
                "empty" => println!("Is the tree empty?: {:?}", tree.empty_tree()),
                "print tree" => {print!("Your tree: \n"); 
                tree.print_tree_str();},
                "print inorder" => {print!("Your tree: ");
                    tree.print_inorder();},
                "exit" => return,
                _ => println!("Command not recognized."),
            }
        }
    }
    
    
    
    
    
pub fn main(){

        println!("           ");
        println!("Hello, Welcome to Trees, Trees and more Trees! ");
        println!("Presented by Fouzia, Duvvuri, Harish and Hossein");
        println!("               ");
        println!("The below are the trees that are Available in our Interface: \n\n1) BST: Binary Search Tree \n2) RBT: Red-Black Tree\n3) AVL: Adelson-Velsky and Landis tree\n");
        println!("           ");
        println!("To start testing a new tree, select your choice of Tree: ");
        println!("                ");
        run_comm_line_int();
}