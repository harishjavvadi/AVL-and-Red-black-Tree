use std::cell::RefCell;
use std::rc::Rc;
use std::fmt;
use std::cmp::{Ord, Ordering};

use crate::common::{TreeNode, Tree};

type RcRefBaseNode<T> = Rc<RefCell<BinarySearchTreeNode<T>>>;
type BaseNodeLink<T> = Option<RcRefBaseNode<T>>;

pub struct BinarySearchTreeNode<T: Ord + Copy + fmt::Debug> {
    pub data: T,
    left: BaseNodeLink<T>,
    right: BaseNodeLink<T>,
}

impl <T: Ord + Copy + fmt::Debug> TreeNode<T> for BinarySearchTreeNode<T> {
    fn get_left(&self) -> &BaseNodeLink<T> { return &self.left; }
    fn get_right(&self) -> &BaseNodeLink<T> { return &self.right; }
    fn get_data(&self) -> T { return self.data; }
}

impl <T: Ord + Copy + fmt::Debug> BinarySearchTreeNode<T> {
    fn new(data: T) -> BaseNodeLink<T> {
        Some(Rc::new(RefCell::new(Self{
            data,
            left: None,
            right: None
        })))
    }

    fn insert(&mut self, new_value: T) {
        if self.data == new_value {
            return
        }
        let new_node =
            if new_value < self.data {&mut self.left}
            else {&mut self.right};
        match new_node {
            Some(node) => node.borrow_mut().insert(new_value),
            None => {
                *new_node = Self::new(new_value);
            }
        }
    }

    fn _delete_node_have_two_children(left: &RcRefBaseNode<T>) {
        let right_minimum_value = left.borrow().right.as_ref().unwrap().borrow().minimum_value();
        left.borrow_mut().delete(right_minimum_value);
        left.borrow_mut().data = right_minimum_value;
    }

    fn _delete_right(&mut self, val: T) {
        if let Some(right) = self.right.as_ref() {
            if right.borrow().data == val {
                if right.borrow().left.is_none() && right.borrow().right.is_none() {
                    self.right = None;
                } else if right.borrow().left.is_none() && !right.borrow().right.is_none() {
                    self.right.take().map(|node| {
                        self.right = node.borrow().right.clone()
                    });
                } else if !right.borrow().left.is_none() && right.borrow().right.is_none() {
                    self.right.take().map(|node| {
                        self.right = node.borrow().left.clone()
                    });
                } else {
                    Self::_delete_node_have_two_children(right);
                }
            } else {
                right.borrow_mut().delete(val);
            }
        }
    }

    fn _delete_left(&mut self, val: T) {
        if let Some(left) = self.left.as_ref() {
            if left.borrow().data == val {
                if left.borrow().left.is_none() && left.borrow().right.is_none() {
                    self.left = None;
                } else if left.borrow().left.is_none() && !left.borrow().right.is_none() {
                    self.left.take().map(|node| {
                        self.left = node.borrow().right.clone()
                    });
                } else if !left.borrow().left.is_none() && left.borrow().right.is_none() {
                    self.left.take().map(|node| {
                        self.left = node.borrow().left.clone()
                    });
                } else {
                    Self::_delete_node_have_two_children(left);
                }
            } else {
                left.borrow_mut().delete(val);
            }
        }
    }

    fn delete(&mut self, val: T) {
        match self.data.cmp(&val) {
            Ordering::Greater => self._delete_left(val),
            Ordering::Less => self._delete_right(val),
            _ => unreachable!(),
        }
    }

    fn print_tree_str(&self, prefix: String, is_left: bool) {
        if let Some(right) = &self.right {
            right.borrow().print_tree_str(format!("{}{}", prefix, if is_left { "│   " } else { "    " }), false);
        }

        println!("{}{} {:?}", prefix, if is_left { "└── " } else { "┌── " }, self.data);

        if let Some(left) = &self.left {
            left.borrow().print_tree_str(format!("{}{}", prefix, if is_left { "    " } else { "│   " }), true);
        }
    }
}

pub struct BinarySearchTree<T: Ord + Copy + fmt::Debug> {root: BaseNodeLink<T>}

impl <T: Ord + Copy + fmt::Debug> Tree<T, BinarySearchTreeNode<T>> for BinarySearchTree<T> {
    fn get_root(&self) -> &BaseNodeLink<T> {
        &self.root
    }
}

impl<T: Ord + Copy + fmt::Debug> BinarySearchTree<T> {

    pub fn new() -> Self {
        Self{ root: None }
    }

    pub fn insert(&mut self, new_val: T) {
        if self.root.is_none() {
            self.root = Some(Rc::new(RefCell::new(BinarySearchTreeNode{
                data: new_val,
                left: None,
                right: None
            })));
        } else {
            self.root.as_ref().unwrap().borrow_mut().insert(new_val);
        }
    }

    pub fn delete(&mut self, val: T) {
        if self.root.is_none() {
            return
        } else {
            if let Some(root) = self.root.as_ref() {
                if root.borrow().data == val {
                    if root.borrow().left.is_none() && root.borrow().right.is_none() {
                        self.root = None;
                    } else if root.borrow().left.is_none() && !root.borrow().right.is_none() {
                        self.root.take().map(|node| {
                            self.root = node.borrow().right.clone()
                        });
                    } else if !root.borrow().left.is_none() && root.borrow().right.is_none() {
                        self.root.take().map(|node| {
                            self.root = node.borrow().left.clone()
                        });
                    } else {
                        BinarySearchTreeNode::_delete_node_have_two_children(root);
                    }
                } else {
                    root.borrow_mut().delete(val);
                }
            }
        }
    }

    pub fn print_tree_str(&self) {
        if let Some(root) = &self.root {
            root.borrow().print_tree_str(String::new(), false);
        }
    }
        
}

