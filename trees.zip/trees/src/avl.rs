use std::fmt;
use std::rc::Rc;
use std::cmp::Ord;
use std::cell::RefCell;
use crate::common::{TreeNode, Tree};
type RcRefAVLTreeNode<T> = Rc<RefCell<AVLTreeNodeDS<T>>>;
type AVLTreeNodeLink<T> = Option<RcRefAVLTreeNode<T>>;
pub struct AVLTreeNodeDS<T: Ord + Copy + fmt::Debug> {
    pub data: T,
    left: AVLTreeNodeLink<T>,
    right: AVLTreeNodeLink<T>,
    height: usize,
}
pub struct AVLTree<T: Ord + Copy + fmt::Debug> {
    root: AVLTreeNodeLink<T>,
}
impl <T: Ord + Copy + fmt::Debug> TreeNode<T> for AVLTreeNodeDS<T> {
    fn get_left(&self) -> &AVLTreeNodeLink<T> { return &self.left; }
    fn get_right(&self) -> &AVLTreeNodeLink<T> { return &self.right; }
    fn get_data(&self) -> T { return self.data; }
}
impl <T: Ord + Copy + fmt::Debug> Tree<T, AVLTreeNodeDS<T>> for AVLTree<T> {
    fn get_root(&self) -> &AVLTreeNodeLink<T> {
        &self.root
    }
}
impl<T: Ord + Copy + fmt::Debug> AVLTreeNodeDS<T> {
    fn new(data:T) -> AVLTreeNodeLink<T>{
        Some(Rc::new(RefCell::new(Self {
            data,
            left: None,
            right: None,
            height: 1,
        })))
    }

    #[inline]
      fn maximum(int1: usize, int2: usize) -> usize {  
        if int1 > int2 {
            int1
        } else {
            int2
        }
    }

      fn _balance_check(&self) -> bool {  
        let left_node_height = self.get_left().as_ref().map(
            |number| number.borrow().height()
        ).unwrap_or(0);
        let right_node_height = self.get_right().as_ref().map(
            |number| number.borrow().height()
        ).unwrap_or(0);
        let del_height = left_node_height as i64 - right_node_height as i64;
        return if del_height.abs() > 1 {
            println!("{:?} {:?}", left_node_height, right_node_height);
            false
        } else {
            let right_node_balanced = self.get_right().as_ref().map(
                  |number| number.borrow()._balance_check()
            ).unwrap_or(true);
            let left_node_balanced = self.get_left().as_ref().map(
                  |number| number.borrow()._balance_check() 
            ).unwrap_or(true);
            if left_node_balanced && right_node_balanced {
                true
            } else {
                false
            }
        }
    }

fn print_tree_str(node: Option<Rc<RefCell<AVLTreeNodeDS<T>>>>, start: String, left: bool) {
    match node {
        Some(node) => {
            let node_value = node.borrow().data;
            let node_height = node.borrow().height;

            let connect = if left { "└── " } else { "┌── " };

            println!("{}{} {:?} - Height: {}", start, connect, node_value, node_height);

            let child = format!("{}{}", start, if left { "    " } else { "│   " });

            let right_side = node.borrow().right.clone();
            AVLTreeNodeDS::print_tree_str(right_side, child.clone(), false);

            let left_side = node.borrow().left.clone();
            AVLTreeNodeDS::print_tree_str(left_side, child, true);
        }
        None => (),
    }
}

      fn _delta_height(number: &RcRefAVLTreeNode<T>) -> i64 {  
        Self::_left_height(number) as i64 - Self::_right_height(number) as i64

    }


    fn _right_height(number: &RcRefAVLTreeNode<T>) -> usize {
        Self::_height(number.borrow().right.clone())
    }
     fn _left_height(number: &RcRefAVLTreeNode<T>) -> usize {
        Self::_height(number.borrow().left.clone())
    }


    fn _height(node: Option<RcRefAVLTreeNode<T>>) -> usize {
        node.map_or(0, |number| number.borrow().height)
    }
   
    #[allow(unused_mut)]
    fn _right_left_rotate(mut root_node: RcRefAVLTreeNode<T>) -> RcRefAVLTreeNode<T> {
        let right_side = root_node.borrow().right.clone().take().unwrap();
        root_node.borrow_mut().right = Some(Self::_right_rotate(right_side));
        return Self::_left_rotate(root_node)
    }
     #[allow(unused_mut)]
    fn _left_right_rotate(mut root_node: RcRefAVLTreeNode<T>) -> RcRefAVLTreeNode<T> {
        let left_side = root_node.borrow().left.clone().take().unwrap();
        root_node.borrow_mut().left = Some(Self::_left_rotate(left_side));
        return Self::_right_rotate(root_node)
    }
    
    #[allow(unused_mut)]
    fn _left_rotate(mut root_node: RcRefAVLTreeNode<T>) -> RcRefAVLTreeNode<T> {
        let mut new_root_node = root_node.borrow().right.clone().unwrap();
        root_node.borrow_mut().right = new_root_node.borrow().left.clone().take();
         root_node.borrow_mut().height = Self::maximum(

            Self::_left_height(&root_node),
            Self::_right_height(&root_node)
        ) + 1;
        new_root_node.borrow_mut().left = Some(root_node);
        new_root_node.borrow_mut().height = Self::maximum(
            Self::_left_height(&new_root_node),
            Self::_right_height(&new_root_node)
        ) + 1;
        return new_root_node
    }
    #[allow(unused_mut)]
    fn _right_rotate(mut root_node: RcRefAVLTreeNode<T>) -> RcRefAVLTreeNode<T> {
        let mut new_root_node = root_node.borrow().left.clone().unwrap();
        root_node.borrow_mut().left = new_root_node.borrow().right.clone().take();
        root_node.borrow_mut().height = Self::maximum(
            Self::_left_height(&root_node),
            Self::_right_height(&root_node)
        ) + 1;
        new_root_node.borrow_mut().right = Some(root_node);
        new_root_node.borrow_mut().height = Self::maximum(
            Self::_left_height(&new_root_node),
            Self::_right_height(&new_root_node)
        ) + 1;
        return new_root_node
    }
    #[allow(unused_mut)]
    fn insert(node: AVLTreeNodeLink<T>, data: T) -> AVLTreeNodeLink<T> {
        let ret_temp_node = match node {
            Some(mut number) => {
                let node_value = number.borrow().data;
                if data < node_value  {
                    let left = number.borrow().left.clone();
                    number.borrow_mut().left = Self::insert(left, data);
                } else if data > node_value {
                    let right = number.borrow().right.clone();
                    number.borrow_mut().right = Self::insert(right, data);
                }
                number
            },
            None => AVLTreeNodeDS::new(data).unwrap()

        };
        let delta_height = Self::_delta_height(&ret_temp_node);
        let ret_temp_node = if delta_height == 2 {
             if data > ret_temp_node.borrow().left.clone().unwrap().borrow().data {
                Self::_left_right_rotate(ret_temp_node)
            } else {
                Self::_right_rotate(ret_temp_node)
            }
        } else if delta_height == -2 {
              if data > ret_temp_node.borrow().right.clone().unwrap().borrow().data {  
               Self::_left_rotate(ret_temp_node)
            } else {
                Self::_right_left_rotate(ret_temp_node)
            }
        } else {
            ret_temp_node
        };

        ret_temp_node.borrow_mut().height = Self::maximum(
            Self::_left_height(&ret_temp_node),
            Self::_right_height(&ret_temp_node)
        ) + 1;
        Some(ret_temp_node)
    }
    #[allow(unused_variables)]
    fn delete(node: AVLTreeNodeLink<T>, data: T) -> AVLTreeNodeLink<T> {
        let ret_temp_node = match node {
            Some(number) => {
                let node_data = number.borrow().data;
                if node_data == data {
                    let left_side = number.borrow().left.clone();
                    let right_side = number.borrow().right.clone();
                    let ret = match (left_side.clone(), right_side.clone()) {
                        (Some(l), Some(r)) => {
                            let minimum_value = r.borrow().minimum_value();
                            number.borrow_mut().data = minimum_value;
                            let right = number.borrow().right.clone().take();
                            number.borrow_mut().right = Self::delete(right, minimum_value);
                            Some(number)
                        }
                       
                        (Some(l), _) => Some(l),
                        (_, Some(r)) => Some(r),
                        (_, None) => None,
                    };
                    ret
                }
                else if node_data > data  {
                    let left = number.borrow().left.clone();
                    if left.is_none() {
                        return Some(number)
                    } else {
                        let left = number.borrow().left.clone().take();
                        number.borrow_mut().left = Self::delete(left, data);
                    }
                    Some(number)
                }
                else {
                    let right = number.borrow().right.clone();
                    if right.is_none() {
                        return Some(number)
                    } else {
                        let right = number.borrow().right.clone().take();
                        number.borrow_mut().right = Self::delete(right, data);
                    }
                    Some(number)
                }
            },
            None => node
        };
        match ret_temp_node {
            Some(number) => {
                let delta_height = Self::_delta_height(&number);
                let ret_n = if delta_height == 2 {
                    if Self::_left_height(&number.borrow().left.clone().unwrap())
                        >= Self::_right_height(&number.borrow().left.clone().unwrap()) {
                        Self::_right_rotate(number)
                    } else {
                        Self::_left_right_rotate(number)
                    }
                } else if delta_height == -2 {
                    if Self::_right_height(&number.borrow().right.clone().unwrap())
                        >= Self::_left_height(&number.borrow().right.clone().unwrap()) {
                        Self::_left_rotate(number)
                    } else {
                        Self::_right_left_rotate(number)
                    }
                } else {
                    number
                };
                ret_n.borrow_mut().height = Self::maximum(
                    Self::_left_height(&ret_n),
                    Self::_right_height(&ret_n)
                ) + 1;
                Some(ret_n)
            }
            None => ret_temp_node,
        }
    }
}

impl<T: Ord + Copy + fmt::Debug> AVLTree<T> {
    pub fn new() -> Self {
        Self { root: None }
    }


    pub fn insert(&mut self, val: T){
        match self.root.take() {
            Some(r) => self.root = AVLTreeNodeDS::insert(Some(r), val),
            None => self.root = AVLTreeNodeDS::new(val),
        }
    }

    pub fn delete(&mut self, val:T){
        match self.root.take() {
            Some(node) => self.root = AVLTreeNodeDS::delete(Some(node), val),
            None => return
        }
    }

      fn _balance_check(&self) -> bool {
        match self.get_root() {
            Some(node) => node.borrow()._balance_check(),
            None => true
        }
    }
     pub fn print_tree_str(&self) {
       AVLTreeNodeDS::print_tree_str(self.root.clone(), "".to_string(), true);
    }
     
}
 